classdef print_all < sweng_matsymb
end