xyfun = sweng_matsymb(-5);
sweng_matsymb.fun3(xyfun);
